<?php
/* Smarty version 3.1.33, created on 2019-11-19 14:37:01
  from 'D:\wamp64\www\monsite\templates\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dd3fe0db4b7e8_59690730',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7272c314d0eefafd39f2c48b949cd8c9d3f84613' => 
    array (
      0 => 'D:\\wamp64\\www\\monsite\\templates\\index.tpl',
      1 => 1574174205,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dd3fe0db4b7e8_59690730 (Smarty_Internal_Template $_smarty_tpl) {
?><!-- Page Content -->
  <div class="container">
    <div class="row">
      <div class="col-lg-12 text-center">
        <?php if ($_smarty_tpl->tpl_vars['nb_article']->value > 0) {?>
          <h2 class="mt-5">Liste des articles disponibles</h2><br/>
        <?php } else { ?>
          <h2 class="mt-5">Aucun article n'as été trouvé dans la base de données</h2><br/>
        <?php }?>
      </div>
    </div>
    <?php if (!empty($_SESSION['notification'])) {?>
      <div class="row">
        <div class="col-12 center-block">
          <div class="alert alert-<?php echo $_SESSION['notification']['result'];?>
" role="alert">
            <h4><?php echo $_SESSION['notification']['titre'];?>
</h4>
            <?php echo $_SESSION['notification']['message'];?>

          </div>
        </div>
      </div>
    <?php }?>
    <div class="row">
      <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tab_articles']->value, 'value');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['value']->value) {
?>
        <div class="col-6">
          <div class="card" style="width: 100%;">
            <img src="img/<?php echo $_smarty_tpl->tpl_vars['value']->value['id'];?>
.jpg" class="card-img-top">
            <div class="card-body">
              <h5 class="card-title"><?php echo $_smarty_tpl->tpl_vars['value']->value['titre'];?>
</h5>
              <p class="card-text"><?php echo $_smarty_tpl->tpl_vars['value']->value['texte'];?>
</p>
              <?php if ($_smarty_tpl->tpl_vars['connecte']->value == TRUE) {?>
                <a href="article.php?&id=<?php echo $_smarty_tpl->tpl_vars['value']->value['id'];?>
" class="btn btn-primary">Modifier l'article</a>
              <?php }?>
              <p class="text-right"><small class="text-muted">Dernière modification le <?php echo $_smarty_tpl->tpl_vars['value']->value['date_fr'];?>
</small></p>
            </div>
          </div>
        </div>
      <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </div>
    <div>
      <br />
      <div>
        <nav aria-label="">
          <ul class="pagination justify-content-center pagination-lg">
            <?php
$_smarty_tpl->tpl_vars['index1'] = new Smarty_Variable(null, $_smarty_tpl->isRenderingCache);$_smarty_tpl->tpl_vars['index1']->step = 1;$_smarty_tpl->tpl_vars['index1']->total = (int) ceil(($_smarty_tpl->tpl_vars['index1']->step > 0 ? $_smarty_tpl->tpl_vars['nb_total_page']->value+1 - (1) : 1-($_smarty_tpl->tpl_vars['nb_total_page']->value)+1)/abs($_smarty_tpl->tpl_vars['index1']->step));
if ($_smarty_tpl->tpl_vars['index1']->total > 0) {
for ($_smarty_tpl->tpl_vars['index1']->value = 1, $_smarty_tpl->tpl_vars['index1']->iteration = 1;$_smarty_tpl->tpl_vars['index1']->iteration <= $_smarty_tpl->tpl_vars['index1']->total;$_smarty_tpl->tpl_vars['index1']->value += $_smarty_tpl->tpl_vars['index1']->step, $_smarty_tpl->tpl_vars['index1']->iteration++) {
$_smarty_tpl->tpl_vars['index1']->first = $_smarty_tpl->tpl_vars['index1']->iteration === 1;$_smarty_tpl->tpl_vars['index1']->last = $_smarty_tpl->tpl_vars['index1']->iteration === $_smarty_tpl->tpl_vars['index1']->total;?>
              <li class="page-item"><a class="page-link" href="http://localhost/monsite/index.php?&p=<?php echo $_smarty_tpl->tpl_vars['index1']->value;
if (isset($_smarty_tpl->tpl_vars['search']->value)) {?>&search=<?php echo $_smarty_tpl->tpl_vars['search']->value;
}?>"><?php echo $_smarty_tpl->tpl_vars['index1']->value;?>
</a></li>
            <?php }
}
?>
          </ul>
        </nav>
      </div>
    </div>
  <!-- Footer --><?php }
}
