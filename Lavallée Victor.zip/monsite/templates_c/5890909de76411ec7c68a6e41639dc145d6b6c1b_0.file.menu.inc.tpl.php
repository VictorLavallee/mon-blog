<?php
/* Smarty version 3.1.33, created on 2019-11-26 15:55:47
  from 'D:\wamp64\www\monsite\templates\menu.inc.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ddd4b03b96176_98413792',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5890909de76411ec7c68a6e41639dc145d6b6c1b' => 
    array (
      0 => 'D:\\wamp64\\www\\monsite\\templates\\menu.inc.tpl',
      1 => 1574783745,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ddd4b03b96176_98413792 (Smarty_Internal_Template $_smarty_tpl) {
?><body>
  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
    <div class="container">
      <a class="navbar-brand" href="index.php">The Lore of Middle-Earth</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
      <?php if ($_smarty_tpl->tpl_vars['connecte']->value == TRUE) {?>
      <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="index.php">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="article.php">Article</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="utilisateurs.php">Utilisateur</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="deconnexion.php">Deconnexion</a>
          </li>
        </ul>
        <form class="form-inline my-2 my-lg-0 ml-auto" method='get' action='index.php'>
          <input class="form-control mr-md-2" type="text" name="search" placeholder="
            <?php if (isset($_smarty_tpl->tpl_vars['search']->value)) {?>
                <?php echo $_smarty_tpl->tpl_vars['search']->value;?>

            <?php } else { ?>
                Search
            <?php }?>" aria-label="Search">
          <button class="btn btn-outline-light my-2 my-sm-0" type="submit">Search</button>
        </form>
      <?php } else { ?>
      <ul class="navbar-nav">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="utilisateurs.php">Utilisateur</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="connexion.php">Connexion</a>
          </li>
        </ul>
      <?php }?>
      </div>
    </div>
  </nav><?php }
}
