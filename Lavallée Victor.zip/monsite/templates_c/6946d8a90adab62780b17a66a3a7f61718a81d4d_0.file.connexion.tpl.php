<?php
/* Smarty version 3.1.33, created on 2019-11-26 16:01:53
  from 'D:\wamp64\www\monsite\templates\connexion.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ddd4c715d1472_61506942',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6946d8a90adab62780b17a66a3a7f61718a81d4d' => 
    array (
      0 => 'D:\\wamp64\\www\\monsite\\templates\\connexion.tpl',
      1 => 1574784110,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ddd4c715d1472_61506942 (Smarty_Internal_Template $_smarty_tpl) {
?><!-- Page Content -->
<div class="container">
  <div class="row">
    <div class="col-lg-12 text-center">
      <h2 class="mt-5">Connexion</h2>
    </div>
  </div>
  <div class="row">
    <div class="col-lg-12">
      <form method="post" action="connexion.php">
        <div class="form-group">
          <label for="email">E-Mail</label>
          <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="form-group">
          <label for="mdp">Mot de passe</label>
          <input type="password" class="form-control" id="mdp" name="mdp" required>
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Se connecter</button>
      </form>
    </div>
  </div>
</div><?php }
}
