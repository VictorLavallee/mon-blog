<?php
/* Smarty version 3.1.33, created on 2019-11-26 16:00:59
  from 'D:\wamp64\www\monsite\templates\article.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ddd4c3bc1d6a4_53836993',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6555ff981eafa62be3b371417f0e587ff1b8e110' => 
    array (
      0 => 'D:\\wamp64\\www\\monsite\\templates\\article.tpl',
      1 => 1574784057,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ddd4c3bc1d6a4_53836993 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="container">
    <div class="row">
      <div class="col-lg-12 text-center">
        <h2 class="mt-5"><?php echo $_smarty_tpl->tpl_vars['action']->value;?>
 un article</h2><br/>
      </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
          <form method="post" enctype='multipart/form-data' action="article.php">
            <div class="form-group">
              <label for="titre">Titre de l'article : </label>
              <input type="titre" class="form-control" id="titre" name="titre" value="<?php echo $_smarty_tpl->tpl_vars['titre']->value;?>
" required>
            </div>
            <div class="form-group">
              <label for="texte">Contenu de l'article</label>
              <textarea class="form-control" id="texte" name="texte" rows="5" required><?php echo $_smarty_tpl->tpl_vars['texte']->value;?>
</textarea>
            </div>
            <div class="form-group">
              <label for="id">Image liée à l'article</label>
              <?php if (($_smarty_tpl->tpl_vars['action']->value == "Ajouter")) {?>
                  <input type="file" class="form-control-file" id="id" name="id" required>
              <?php }?>
              <?php if (($_smarty_tpl->tpl_vars['action']->value == "Modifier")) {?>
                  <input type="hidden" id="id" name="id_bdd" value="<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
"><img src="img/<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
.jpg" /><input type="file" class="form-control-file" id="id" name="id" required>
              <?php }?>
            </div>
            <div class="form-group form-check">
              <input type="checkbox" class="form-check-input" id="publie" name="publie" <?php if (($_smarty_tpl->tpl_vars['publie']->value == 1)) {?>checked<?php }?>>
              <label class="form-check-label" for="exampleCheck1">Publier l'article</label>
            </div>
            <button type="submit" name="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
" class="btn btn-primary"><?php echo $_smarty_tpl->tpl_vars['action']->value;?>
 l'article</button>
          </form>
        </div>
    </div>
  </div><?php }
}
