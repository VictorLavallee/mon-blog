<?php
/* Smarty version 3.1.33, created on 2019-11-26 16:01:29
  from 'D:\wamp64\www\monsite\templates\utilisateurs.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ddd4c59070f33_92018523',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd41fd5e7d98f311511e9ce297980640cf41c482b' => 
    array (
      0 => 'D:\\wamp64\\www\\monsite\\templates\\utilisateurs.tpl',
      1 => 1574784086,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ddd4c59070f33_92018523 (Smarty_Internal_Template $_smarty_tpl) {
?><!-- Page Content -->
  <div class="container">
    <div class="row">
      <div class="col-lg-12 text-center">
        <h2 class="mt-5">Ajouter un utilisateur</h2><br/>
      </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <form method="post" action="utilisateurs.php">
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="nom">Nom</label>
                <input type="text" class="form-control" id="nom" name="nom" placeholder="Nom de famille" required>
              </div>
              <div class="form-group col-md-6">
                <label for="prenom">Prénom</label>
                <input type="text" class="form-control" id="prenom" name="prenom" placeholder="Prénom" required>
              </div>
            </div>
            <div class="form-group">
              <label for="email">E-Mail</label>
              <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="form-group">
              <label for="mdp">Mot de passe</label>
              <input type="password" class="form-control" id="mdp" name="mdp" required>
            </div>
            <button type="submit" name="submit" class="btn btn-primary">Valider la saisie</button>
          </form>
        </div>
    </div>
  </div><?php }
}
