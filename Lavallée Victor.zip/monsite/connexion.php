<?php
require_once 'config/init.conf.php';
require_once 'config/bdd.conf.php';
require_once 'config/connexion.conf.php';
include_once 'includes/fonctions.inc.php';
require_once 'vendor/smarty/Smarty.class.php';

/* @var $bdd PDO */

if($connecte == FALSE) {
    if(isset($_POST['submit'])) {
        $email = $_POST['email'];
        $mdp = $_POST['mdp'];
    
        $sth = $bdd->prepare("SELECT * FROM utilisateurs WHERE email = :email AND mdp = :mdp");  //Requête SQL
        $sth->bindValue(':email', $email, PDO::PARAM_STR);
        $sth->bindValue(':mdp', $mdp, PDO::PARAM_STR);//Paramètre de la requête
        $sth->execute();    //Execution de la requête
    
        if($sth->rowCount() == 1) {
            //La connexion est ok
            $donnees = $sth->fetch(PDO::FETCH_ASSOC);
            $sid = $donnees['email'] . time();
            $sid_hache = md5($sid);
        
            setcookie('sid', $sid_hache, time() + 3600);
        
            $sth_update = $bdd->prepare("UPDATE utilisateurs SET sid = :sid WHERE id = :id");
            $sth_update->bindValue(':sid', $sid_hache, PDO::PARAM_STR);
            $sth_update->bindValue(':id', $donnees['id'], PDO::PARAM_INT);
            $result_insert = $sth_update->execute();
        
            if($result_insert == true) {
                $message = "Bonjour ".$donnees['prenom']." ".$donnees['nom'].". Vous êtes maintenant connecté !";
            } else {
                $message = "Une erreur s'est produite durant la connexion. Veuillez ré-essayer.";
            }
        
            notifications($result_insert, $message);
            header('Location: index.php');
            exit();
        } else {
            //La connexion est bloqué
            $_SESSION['notification']['result'] = "danger";
            $_SESSION['notification']['titre'] = "Action échouée ...";
            $_SESSION['notification']['message'] = "L'e-mail ou le mot de passe sont incorrect. Veulliez ré-essayer";
            header('Location: connexion.php');
            exit();
        }
    } else {
    
    $smarty = new Smarty();

    $smarty->setTemplateDir('templates/');
    $smarty->setCompileDir('templates_c/');

    include_once 'includes/header.inc.php';
    include_once 'includes/menu.inc.php';
    $smarty->display('connexion.tpl');
    include_once 'includes/footer.inc.php';

    unset($_SESSION['notification']);
    
    }
} else {
    header('Location: index.php');
}