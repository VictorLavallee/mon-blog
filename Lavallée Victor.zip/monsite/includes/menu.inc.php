<body>
  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
    <div class="container">
      <a class="navbar-brand" href="index.php">The Lore of Middle-Earth</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <?php if($connecte == TRUE){ ?>
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="index.php">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="article.php">Article</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="utilisateurs.php">Utilisateur</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="deconnexion.php">Deconnexion</a>
          </li>
        </ul>
        <form class="form-inline my-2 my-lg-0 ml-auto" method='get' action='index.php'>
          <input class="form-control mr-md-2" type="text" name="search" placeholder="<?php if(isset($_GET['search'])){echo $_GET['search'];}else{echo 'Search';} ?>" aria-label="Search">
          <button class="btn btn-outline-light my-2 my-sm-0" type="submit">Search</button>
        </form>
        <?php }else { ?>     
        <ul class="navbar-nav">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="utilisateurs.php">Utilisateur</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="connexion.php">Connexion</a>
          </li>
        </ul>
        <?php } ?>
      </div>
    </div>
  </nav>