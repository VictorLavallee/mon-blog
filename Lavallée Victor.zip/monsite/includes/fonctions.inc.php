<?php
function nb_total_article($bdd){
    $sth = $bdd->prepare("SELECT COUNT(*) AS total_articles FROM articles WHERE publie = :publie");  //Requête SQL
    $sth->bindValue('publie', 1, PDO::PARAM_INT);   //Paramètre de la requête
    $sth->execute();
    $result = $sth->fetch(PDO::FETCH_ASSOC);
    $total_articles = $result['total_articles'];
    return $total_articles;
}

function nb_total_article_recherche($bdd, $search){
    $sth = $bdd->prepare("SELECT COUNT(*) AS total_articles FROM articles WHERE publie = :publie AND (titre LIKE :search OR texte LIKE :search)");  //Requête SQL
    $sth->bindValue(':publie', 1, PDO::PARAM_INT);   //Paramètre de la requête
    $sth->bindValue(':search', $search, PDO::PARAM_STR);
    $sth->execute();
    $result = $sth->fetch(PDO::FETCH_ASSOC);
    $total_articles = $result['total_articles'];
    return $total_articles;
}

function pagination($page_courant, $nb_articles_par_page){
    $index = ($page_courant - 1) * $nb_articles_par_page;
    return $index;
}