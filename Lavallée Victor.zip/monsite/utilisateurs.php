<?php
require_once 'config/init.conf.php';
require_once 'config/bdd.conf.php';
require_once 'config/connexion.conf.php';
include_once 'includes/fonctions.inc.php';
require_once 'vendor/smarty/Smarty.class.php';

/* @var $bdd PDO */

if(isset($_POST['submit'])){    //Si le formulaire à été poster
    //Création des variables
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $email = $_POST['email'];
    $mdp = $_POST['mdp'];

    //Partie SQL + BDD
    $sth = $bdd->prepare("INSERT INTO utilisateurs (nom, prenom, email, mdp) VALUES (:nom, :prenom, :email, :mdp)");  //requete SQL
    $sth->bindValue(':nom', $nom, PDO::PARAM_STR);  //Attribution dess valeurs à la requete
    $sth->bindValue(':prenom', $prenom, PDO::PARAM_STR);
    $sth->bindValue(':email', $email, PDO::PARAM_STR);
    $sth->bindValue(':mdp', $mdp, PDO::PARAM_STR);
    $result_insert = $sth->execute();    //Execution de la requette
    
    $id_insert = $bdd->lastInsertId();  //Recupere le dernier ID entrer dans la base de données
    
    if($result_insert == true) {
        $message = "L'utilisateur à été créé";
    } else {
        $message = "Une erreur s'est produite, l'utilisateur n'as pas été créé. Veuillez ré-essayer.";
    }
    
    notifications($result_insert, $message);
    
    //Redirection vers l'index
    header('Location: index.php');
} else {
    $smarty = new Smarty();

    $smarty->setTemplateDir('templates/');
    $smarty->setCompileDir('templates_c/');

    //** un-comment the following line to show the debug console
    //$smarty->debugging = true;

    include_once 'includes/header.inc.php';
    include_once 'includes/menu.inc.php';
    $smarty->display('utilisateurs.tpl');
    include_once 'includes/footer.inc.php';

    unset($_SESSION['notification']);
}