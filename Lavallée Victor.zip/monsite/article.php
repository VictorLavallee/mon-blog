<?php
require_once 'config/init.conf.php';
require_once 'config/bdd.conf.php';
require_once 'config/connexion.conf.php';
include_once 'includes/fonctions.inc.php';
require_once 'vendor/smarty/Smarty.class.php';

/* @var $bdd PDO */

if($connecte == TRUE){
    if(isset($_GET['id'])){ //Si on modifie un article
        $action = "Modifier";
        $get_article = $bdd->prepare("SELECT id, titre, texte FROM articles WHERE id = :id");
        $get_article->bindValue(':id', $_GET["id"], PDO::PARAM_INT);
        $get_article->execute();
        $data_article = $get_article->fetchAll(PDO::FETCH_ASSOC);
        foreach ($data_article as $value) {
            $titre = $value['titre'];
            $texte = $value['texte'];
            $id = $value['id'];
            $publie = 1;
        }
    }

    else { //Si on ajoute un article
        $action = "Ajouter";
        $titre = "";
        $texte = "";
        $id = "";
        $publie = 0;
    }

    if(isset($_POST['Ajouter'])){    //Si le formulaire à été poster
        //Création des variables
        $titre = $_POST['titre'];
        $texte = $_POST['texte'];
        $publie = isset($_POST['publie']) ? 1 : 0;  //Vérifie si "publie" à été cocher ou non
        $date = date('Y-m-d');  //Récuperer la date sour la forme "AAAA-mm-jj"

        //Partie SQL + BDD
        $sth = $bdd->prepare("INSERT INTO articles (titre, texte, publie, date) VALUES (:titre, :texte, :publie, :date)");  //requete SQL
        $sth->bindValue(':titre', $titre, PDO::PARAM_STR);  //Attribution des valeurs à la requete
        $sth->bindValue(':texte', $texte, PDO::PARAM_STR);
        $sth->bindValue(':publie', $publie, PDO::PARAM_INT);
        $sth->bindValue(':date', $date, PDO::PARAM_STR);
        $result_insert = $sth->execute();    //Execution de la requette
    
        $id_insert = $bdd->lastInsertId();  //Recupere le dernier ID entrer dans la base de données
    
        //Traitement de l'image
        if($_FILES['id']['error'] == 0){    //S'il n'y as pas eu d'erreur au chargement de l'image
            $ext = pathinfo($_FILES['id']['tmp_name'], PATHINFO_EXTENSION); 
            move_uploaded_file($_FILES['id']['tmp_name'], 'img/' . $id_insert . '.jpg');    //Enregistrement de l'image dans un dossier specifier
        }

        if($result_insert == true) {
            $message = "Votre article à bien été poster sur ce site";
        } else {
            $message = "Une erreur s'est produite, votre article n'est pas disponible. Veuillez ré-essayer.";
        }
    
        notifications($result_insert, $message);
        //Redirection vers l'index
        header('Location: index.php');
    }
    else if(isset($_POST['Modifier'])){
        $titre = $_POST['titre'];
        $texte = $_POST['texte'];
        $publie = isset($_POST['publie']) ? 1 : 0;  //Vérifie si "publie" à été cocher ou non
        $date = date('Y-m-d');  //Récuperer la date sour la forme "AAAA-mm-jj"
        $id = $_POST['id_bdd'];
        
        $sth = $bdd->prepare("UPDATE articles SET titre = :titre, texte = :texte, publie = :publie, date = :date WHERE id = :id");  //requete SQL
        $sth->bindValue(':titre', $titre, PDO::PARAM_STR);  //Attribution dess valeurs à la requete
        $sth->bindValue(':texte', $texte, PDO::PARAM_STR);
        $sth->bindValue(':publie', $publie, PDO::PARAM_INT);
        $sth->bindValue(':date', $date, PDO::PARAM_STR);
        $sth->bindValue(':id', $id, PDO::PARAM_INT);
        $result_insert = $sth->execute();    //Execution de la requette
        
        if($_FILES['id']['error'] == 0){    //S'il n'y as pas eu d'erreur au chargement de l'image
            $ext = pathinfo($_FILES['id']['tmp_name'], PATHINFO_EXTENSION); 
            move_uploaded_file($_FILES['id']['tmp_name'], 'img/' . $id . '.jpg');    //Enregistrement de l'image dans un dossier specifier
        }
        
        if($result_insert == true) {
            $message = "Votre article à bien été modifier";
        } else {
            $message = "Une erreur s'est produite, votre article n'est pas disponible. Veuillez ré-essayer.";
        }
        
        notifications($result_insert, $message);
        //Redirection vers l'index
        header('Location: index.php');
    }
    
    else {
        $smarty = new Smarty();

        $smarty->setTemplateDir('templates/');
        $smarty->setCompileDir('templates_c/');

        //Transmission des variables au template
        $smarty->assign('action', $action);
        $smarty->assign('texte', $texte);
        $smarty->assign('titre', $titre);
        $smarty->assign('id', $id);
        $smarty->assign('publie', $publie);

        include_once 'includes/header.inc.php';
        include_once 'includes/menu.inc.php';
        $smarty->display('article.tpl');
        include_once 'includes/footer.inc.php';

        unset($_SESSION['notification']);
    }

} else {
    header('Location: index.php');
}