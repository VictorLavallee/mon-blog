<?php
require_once 'config/init.conf.php';
require_once 'config/bdd.conf.php';
require_once 'config/connexion.conf.php';
include_once 'includes/fonctions.inc.php';
require_once 'vendor/smarty/Smarty.class.php';

/* @var $bdd PDO */

$page_courante = !empty($_GET['p']) ? $_GET['p'] : 1;

if(isset($_GET['search'])){
    $search = '%'.$_GET['search'].'%';
    $nb_total_articles = nb_total_article_recherche($bdd, $search);
    $nb_total_page = ceil($nb_total_articles / _nb_art_par_page);
    $index = pagination($page_courante, _nb_art_par_page);
    
    $sth = $bdd->prepare("SELECT id, titre, texte, DATE_FORMAT(date, '%d/%m/%Y') AS date_fr, publie FROM articles WHERE publie = :publie AND (titre LIKE :search OR texte LIKE :search) LIMIT :index, :nb_article_par_page");
    $sth->bindValue(':publie', 1, PDO::PARAM_BOOL);
    $sth->bindValue(':search', $search, PDO::PARAM_STR);
    $sth->bindValue(':index', $index, PDO::PARAM_INT);
    $sth->bindValue(':nb_article_par_page', _nb_art_par_page, PDO::PARAM_INT);
    $sth->execute();
    $nb_article = $sth->rowCount();
    
    $tab_articles = $sth->fetchAll(PDO::FETCH_ASSOC);
}
else{
    $nb_total_articles = nb_total_article($bdd);
    $nb_total_page = ceil($nb_total_articles / _nb_art_par_page);
    $index = pagination($page_courante, _nb_art_par_page);

    $sth = $bdd->prepare("SELECT id, titre, texte, DATE_FORMAT(date, '%d/%m/%Y') AS date_fr, publie FROM articles WHERE publie = :publie LIMIT :index, :nb_article_par_page");  //Requête SQL
    $sth->bindValue(':publie', 1, PDO::PARAM_BOOL);
    $sth->bindValue(':index', $index, PDO::PARAM_INT);
    $sth->bindValue(':nb_article_par_page', _nb_art_par_page, PDO::PARAM_INT);//Paramètre de la requête
    $sth->execute();    //Execution de la requête
    $nb_article = $sth->rowCount();
    
    $tab_articles = $sth->fetchAll(PDO::FETCH_ASSOC);
}

$smarty = new Smarty();

$smarty->setTemplateDir('templates/');
$smarty->setCompileDir('templates_c/');

//Transmission des variables au template
$smarty->assign('tab_articles', $tab_articles);
$smarty->assign('nb_total_page', $nb_total_page);
$smarty->assign('connecte', $connecte);
$smarty->assign('nb_article', $nb_article);
if(isset($_GET['search'])){
    $smarty->assign('search', $_GET['search']);
}

//** un-comment the following line to show the debug console
//$smarty->debugging = true;

include_once 'includes/header.inc.php';
include_once 'includes/menu.inc.php';
$smarty->display('index.tpl');
include_once 'includes/footer.inc.php';

unset($_SESSION['notification']);