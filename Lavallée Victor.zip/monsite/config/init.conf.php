<?php
session_start();

//Affichage des erreurs et avertissements PHP
error_reporting(E_ALL);
ini_set("display_errors", 1);
define('_nb_art_par_page', 2);

function print_r2($ma_variable){
    echo '<pre>';
    print_r($ma_variable);
    echo '</pre>';
}

function notifications($result_insert, $message) {
    if($result_insert == true) {
        $_SESSION['notification']['result'] = "success";
        $_SESSION['notification']['titre'] = "Action réussi !";
        $_SESSION['notification']['message'] = $message;
    }
    else {
        $_SESSION['notification']['result'] = "danger";
        $_SESSION['notification']['titre'] = "Action échouée ...";
        $_SESSION['notification']['message'] = $message;
    }
    return true;
}

